$("#Home span ").click(function(){
    $('.navegation').show(1000);
    $("span i").css("padding-left","200px");
    
})
$(".close").click(function(){
    
    $('.navegation').hide(1000);
    $("span i").css("padding-left","0px");
    
})

$(".main-Details h4").click(function(){
   $(this).next(".details").toggle(1000);
    
});

var countDownDate= new Date(2020,12,1).getTime();
var updateTime= setInterval(function(){
    
     var now = new Date().getTime();
     var difTime= countDownDate-now;
    var days = Math.floor(difTime / (1000 * 60 * 60 * 24));
    var hours = Math.floor((difTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((difTime % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((difTime % (1000 * 60)) / 1000);
    
    document.getElementById("Days").innerHTML = "<h3> -"+  days + " D"+"</h3>";

				document.getElementById("Hours").innerHTML ="<h3> -"+  hours + " h"+"</h3>";
				document.getElementById("Min").innerHTML = "<h3> -"+  minutes + " m"+"</h3>";
				document.getElementById("Sec").innerHTML = "<h3> -"+  seconds + " s"+"</h3>";

    
    
    
    
    
    
    
})
                  

$(function(){
     var maxCharacter=100;
    $("textarea").keyup(function(){
        var length=$(this).val().length;
        var difCharacter=maxCharacter-length;
        
                if(difCharacter<=0)
            {
                 $(".num").text("your available character finished");
                
            }
        else{
        
        $(".num").text(difCharacter);
        }
        
    })
    
    
    
})
$("#clickBtn").click(function(){
    window.alert("Enjoy The Party");
    
})
 $(".navbar .nav a").click(function(){

     let aHref=$(this).attr("href");
    let  profileOffset =$(aHref).offset().top;
 
    $("body,html").animate({scrollTop:profileOffset},2000);

    })


      
  